$(document).ready(function () {
    $("#login").click(function () {

        var email = $("#email").val();
        var password = $("#password").val();

        if (email == '' || password == '') {

            alert("Please fill all fields...!!!!!!");

        } else {

            window.location.href = "famous.html";
            alert("Login successfully!");

        }
    });
});
