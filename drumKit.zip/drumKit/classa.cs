using System;
using System.IO;

public class WelcomeUser
{
    public static void main()
    {
      Console.WriteLine("Welcome to our Place... we are glad to have you here !!");

      Console.WriteLine("Please enter today's date : ");
      DateTime.Now.ToString("yyyy-MM-dd");
    }
}