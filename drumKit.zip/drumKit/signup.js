$(document).ready(function () {
    $("#signup").click(function () {

        var firstName = $("#firstName").val();
        var lastName = $("#lasttName").val();
        var email = $("#email").val();
        var password = $("#pwd").val();
        var cpassword = $("#confirmpwd").val();

        if (firstName == '' || lastName == '' || email == '' || password == '' || cpassword == '') {

            alert("Please fill all fields...!!!!!!");

        } else if ((password.length) < 8) {

            alert("Password should atleast 8 character in length...!!!!!!");

        } else if (!(password).match(cpassword)) {

            alert("Your passwords don't match. Try again?");

        } else {

                window.location.href = "famous.html";
                alert("register successfully!");
        }
    });
});